package com.s7rawi.elemental;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.registry.Registry;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

import java.util.List;

public class S7rawiElementalPickaxeMod implements ModInitializer {
    public static final String MOD_ID = "s7rawi_elemental_pickaxe";
    public static final Item S7RAWI_ELEMENTAL_PICKAXE = Registry.register(
            Registries.ITEM,
            Identifier.of(MOD_ID, "s7rawi_elemental_pickaxe"),
            new ElementalPickaxe(new Item.Settings().maxCount(1).maxDamage(3000))
    );

    private static final ThreadLocal<Boolean> BREAKING_AREA = ThreadLocal.withInitial(() -> false);

    @Override
    public void onInitialize() {
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (world.isClient() || BREAKING_AREA.get()) return;
            ItemStack held = player.getMainHandStack();
            if (!(held.getItem() instanceof ElementalPickaxe)) return;
            BREAKING_AREA.set(true);
            try {
                for (int dx = -1; dx <= 1; dx++) {
                    for (int dy = -1; dy <= 1; dy++) {
                        for (int dz = -1; dz <= 1; dz++) {
                            if (dx == 0 && dy == 0 && dz == 0) continue;
                            BlockPos target = pos.add(dx, dy, dz);
                            if (!world.getBlockState(target).isAir() && canMine(world.getBlockState(target))) {
                                world.breakBlock(target, true, player);
                                held.damage(1, player, PlayerEntity.getSlotForHand(Hand.MAIN_HAND));
                            }
                        }
                    }
                }
            } finally {
                BREAKING_AREA.set(false);
            }
        });
    }

    private static boolean canMine(BlockState state) {
        return !state.isOf(Blocks.BEDROCK) && !state.isIn(BlockTags.IMPERMEABLE);
    }

    public static class ElementalPickaxe extends PickaxeItem {
        public ElementalPickaxe(Item.Settings settings) {
            super(ToolMaterial.NETHERITE, settings);
        }

        @Override
        public ActionResult useOnBlock(net.minecraft.item.ItemUsageContext context) {
            if (context.getWorld().isClient()) return ActionResult.SUCCESS;
            PlayerEntity player = context.getPlayer();
            if (player == null) return ActionResult.PASS;
            if (player.isSneaking()) {
                return smeltOreIntoBlock(context.getWorld(), context.getBlockPos(), player) ? ActionResult.SUCCESS : ActionResult.PASS;
            }
            return ActionResult.PASS;
        }

        @Override
        public net.minecraft.util.TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
            ItemStack stack = player.getStackInHand(hand);
            if (player.isSneaking()) {
                return net.minecraft.util.TypedActionResult.success(stack, world.isClient());
            }
            if (!world.isClient()) {
                Direction facing = player.getHorizontalFacing();
                for (int forward = 1; forward <= 50; forward++) {
                    for (int side = -1; side <= 1; side++) {
                        for (int y = -1; y <= 1; y++) {
                            int x = player.getBlockPos().getX();
                            int z = player.getBlockPos().getZ();
                            if (facing.getAxis() == Direction.Axis.Z) {
                                z += forward * facing.getOffsetZ();
                                x += side;
                            } else {
                                x += forward * facing.getOffsetX();
                                z += side;
                            }
                            BlockPos pos = new BlockPos(x, player.getBlockPos().getY() + y, z);
                            BlockState state = world.getBlockState(pos);
                            if (!state.isAir() && canMine(state)) {
                                world.breakBlock(pos, true, player);
                            }
                        }
                    }
                }
                world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_BREEZE_WIND_BURST, SoundCategory.PLAYERS, 1.2f, 1.0f);
                stack.damage(1, player, PlayerEntity.getSlotForHand(hand));
            }
            return net.minecraft.util.TypedActionResult.success(stack, world.isClient());
        }
    }

    private static boolean smeltOreIntoBlock(World world, BlockPos pos, PlayerEntity player) {
        BlockState state = world.getBlockState(pos);
        net.minecraft.block.Block block = state.getBlock();
        net.minecraft.block.Block result = null;
        if (block == Blocks.IRON_ORE || block == Blocks.DEEPSLATE_IRON_ORE) result = Blocks.IRON_BLOCK;
        else if (block == Blocks.GOLD_ORE || block == Blocks.DEEPSLATE_GOLD_ORE) result = Blocks.GOLD_BLOCK;
        else if (block == Blocks.COPPER_ORE || block == Blocks.DEEPSLATE_COPPER_ORE) result = Blocks.COPPER_BLOCK;
        else if (block == Blocks.DIAMOND_ORE || block == Blocks.DEEPSLATE_DIAMOND_ORE) result = Blocks.DIAMOND_BLOCK;
        else if (block == Blocks.EMERALD_ORE || block == Blocks.DEEPSLATE_EMERALD_ORE) result = Blocks.EMERALD_BLOCK;
        else if (block == Blocks.REDSTONE_ORE || block == Blocks.DEEPSLATE_REDSTONE_ORE) result = Blocks.REDSTONE_BLOCK;
        else if (block == Blocks.LAPIS_ORE || block == Blocks.DEEPSLATE_LAPIS_ORE) result = Blocks.LAPIS_BLOCK;
        else if (block == Blocks.NETHER_QUARTZ_ORE) result = Blocks.QUARTZ_BLOCK;
        else if (block == Blocks.NETHER_GOLD_ORE) result = Blocks.GOLD_BLOCK;
        if (result == null) return false;
        world.setBlockState(pos, result.getDefaultState());
        world.playSound(null, pos, SoundEvents.BLOCK_FURNACE_FIRE_CRACKLE, SoundCategory.BLOCKS, 0.8f, 1.2f);
        return true;
    }
}
